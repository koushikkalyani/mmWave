
"use strict";

let RadarScan = require('./RadarScan.js');
let RadarScan (copy) = require('./RadarScan (copy).js');

module.exports = {
  RadarScan: RadarScan,
  RadarScan (copy): RadarScan (copy),
};
